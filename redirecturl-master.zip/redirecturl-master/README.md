# Rút gọn link bằng HTML + Js

Sử dụng Google Script làm API
1. Đổi IDsheet trong code.gs và tạo Google App Script copy dán vào và deploy thành webapp.

2. Cần cấp quyền edit và anonymous để thành API public.
  
3. Thay đổi URL API trong index.html và addlink.html



# English translation 

# Shorten links using the google script API

### Requirements

1. Change the IDsheet in code.gs
2. Create a google app script, and paste into. 
3. Change API URLS in index.html and addlink.html

<b>Edit & Anonymous permissions are needed to make the API public</b>
